#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <pwd.h>
#include <grp.h>
#include <time.h>
int compare_strings(const void *a, const void *b)
{
        const char *s1 = *(const char **)a;
        const char *s2 = *(const char **)b;
        return strcmp(s1, s2);
}
void ls_l()
{
        int x = 0;
        int block = 0;
        char *strings[2048];
        DIR *file;
        struct dirent *open;
        file = opendir(".");
        while ((open = readdir(file)) != NULL)
        {
                if (open->d_name[0] == '.')
                {
                        continue;
                }
                strings[x] = open->d_name;
                x = x + 1;
        }
        qsort(strings, x, sizeof(char *), compare_strings);
        struct stat file_stat;
        for (int i = 0; i < x; i = i + 1)
        {
                stat(strings[i], &file_stat);
                // file_stat.st_blocks = block;
                block = file_stat.st_blocks + block;
        }
        printf("total %d \n", block / 2);

        for (int i = 0; i < (x); i = i + 1)
        {
                stat(strings[i], &file_stat);
                printf("%c%c%c%c%c%c%c%c%c%c ",
                       (file_stat.st_mode & S_IFDIR) ? 'd' : '-',
                       (file_stat.st_mode & S_IRUSR) ? 'r' : '-',
                       (file_stat.st_mode & S_IWUSR) ? 'w' : '-',
                       (file_stat.st_mode & S_IXUSR) ? 'x' : '-',
                       (file_stat.st_mode & S_IRGRP) ? 'r' : '-',
                       (file_stat.st_mode & S_IWGRP) ? 'w' : '-',
                       (file_stat.st_mode & S_IXGRP) ? 'x' : '-',
                       (file_stat.st_mode & S_IROTH) ? 'r' : '-',
                       (file_stat.st_mode & S_IWOTH) ? 'w' : '-',
                       (file_stat.st_mode & S_IXGRP) ? 'x' : '-');
                printf("%ld ", file_stat.st_nlink);
                struct passwd *pw = getpwuid(file_stat.st_uid);
                printf(" %s ", pw->pw_name);
                struct group *gr = getgrgid(file_stat.st_gid);
                printf("%s ", gr->gr_name);
                printf("%8ld ", file_stat.st_size);
                char *time = ctime(&file_stat.st_mtime);
                time[16] = '\0';
                printf("%s ", (time) + 4);
                printf("%s \n", strings[i]);
        }
        closedir(file);
}
void ls_r()
{
        int x = 0;
        int block = 0;
        char *strings[2048];
        DIR *file;
        struct dirent *open;
        file = opendir(".");
        while ((open = readdir(file)) != NULL)
        {
                if (open->d_name[0] == '.')
                {
                        continue;
                }
                strings[x] = open->d_name;
                x = x + 1;
        }
        qsort(strings, x, sizeof(char *), compare_strings);
        for (int i = 0; i < x; i = i + 1)
        {
                printf("%s\n", strings[x - 1 - i]);
        }
        closedir(file);
}
void ls()
{
        int x = 0;
        int block = 0;
        char *strings[2048];
        DIR *file;
        struct dirent *open;
        file = opendir(".");
        while ((open = readdir(file)) != NULL)
        {
                if (open->d_name[0] == '.')
                {
                        continue;
                }
                strings[x] = open->d_name;
                x = x + 1;
        }
        qsort(strings, x, sizeof(char *), compare_strings);
        for (int i = 0; i < x; i = i + 1)
        {
                printf("%s\n", strings[i]);
        }
        closedir(file);
}
void ls_a()
{
        int x = 0;
        int block = 0;
        char *strings[2048];
        DIR *file;
        struct dirent *open;
        file = opendir(".");
        while ((open = readdir(file)) != NULL)
        {
                /* if(open->d_name[0]=='.')
                 {
                         continue;
                 }
                 strings[x]=open->d_name;
                 x=x+1;*/
                printf("%s\n", open->d_name);
        }
        // qsort(strings, x, sizeof(char*), compare_strings);
        /* for(int i=0; i<x ;i=i+1)
         {
                 printf("%s\n",strings[i]);
         }*/
        closedir(file);
}
void ls_s()
{
        int x = 0;
        int block = 0;
        char *strings[2048];
        DIR *file;
        struct dirent *open;
        file = opendir(".");
        while ((open = readdir(file)) != NULL)
        {
                if (open->d_name[0] == '.')
                {
                        continue;
                }
                strings[x] = open->d_name;
                x = x + 1;
        }
        struct stat file_stat;
        for (int i = 0; i < x; i = i + 1)
        {
                stat(strings[i], &file_stat);
                // file_stat.st_blocks = block;
                block = file_stat.st_blocks + block;
        }
        printf("total %d \n", block / 2);
        qsort(strings, x, sizeof(char *), compare_strings);
        for (int i = 0; i < x; i = i + 1)
        {
                stat(strings[i], &file_stat);
                // file_stat.st_blocks = block;
                // block = file_stat.st_blocks + block;
                printf("%ld %s\n", (file_stat.st_blocks) / 2, strings[i]);
        }
        // qsort(strings, x, sizeof(char*), compare_strings);
        /* for(int i=0; i<x ;i=i+1)
         {
                 printf("%ld %s\n",file_stat.st_blocks,strings[i]);
         }
                 while((open=readdir(file))!=NULL)
         {
                 if(open->d_name[0]=='.')
                 {
                         continue;
                 }
                 strings[x]=open->d_name;
                 x=x+1;
                 printf("%ld %s\n", (file_stat.st_blocks)/2,open->d_name);
         }*/
        closedir(file);
}
void ls_U()
{
        int x = 0;
        int block = 0;
        char *strings[2048];
        DIR *file;
        struct dirent *open;
        file = opendir(".");
        while ((open = readdir(file)) != NULL)
        {
                if (open->d_name[0] == '.')
                {
                        continue;
                }
                strings[x] = open->d_name;
                x = x + 1;
        }
        qsort(strings, x, sizeof(char *), compare_strings);
        for (int i = 0; i < x; i = i + 1)
        {
                printf("%s\n", strings[i]);
        }
        closedir(file);
}
