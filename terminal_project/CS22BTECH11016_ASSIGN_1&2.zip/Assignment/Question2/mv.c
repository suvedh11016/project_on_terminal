#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <readline/readline.h>
#include <readline/history.h>
#define BUFFER_SIZE 1024
void mv(char *command_line)
{
    FILE *source_file, *dest_file;
    char opened[1000];
    char closed[1000];
    char c;
    char ch;
    char *space[1000];
    int i = 0;

    // fgets(command_line, sizeof(command_line), stdin);
    char *token = strtok(command_line, " ");

    while (token != NULL)
    {
        space[i] = token;
        i++;
        token = strtok(NULL, " ");
    }
    if (strcmp(space[1], "-i") == 0)
    {
        strcpy(opened, space[2]);
        source_file = fopen(opened, "r");
        if (source_file == NULL)
        {
            fprintf(stderr, "Cannot open source file %s\n", opened);
        }
        strcpy(closed, space[3]);
        dest_file = fopen(closed, "w");
        if (dest_file == NULL)
        {
            fprintf(stderr, "Cannot open destination file %s\n", closed);
            fclose(source_file);
        }
        printf("cp: overwrite '%s'?", closed);
        char response[10];
        fgets(response, sizeof(response), stdin);
        /* if (response[0] != 'y' && response[0] != 'Y')
         {
             printf("cp: not overwritten\n");
             fclose(source_file);
             fclose(dest_file);
         }*/
        if (response[0] == 'y' || response[0] == 'Y')
        {
            char buffer[BUFFER_SIZE];
            size_t bytes_read;
            while ((bytes_read = fread(buffer, 1, sizeof(buffer), source_file)) > 0)
            {
                fwrite(buffer, 1, bytes_read, dest_file);
            }
        }
        else
        {
            printf("mv: not overwritten\n");
        }
        /*  char buffer[BUFFER_SIZE];
          size_t bytes_read;
          while ((bytes_read = fread(buffer, 1, sizeof(buffer), source_file)) > 0)
          {
              fwrite(buffer, 1, bytes_read, dest_file);
          }*/

        fclose(source_file);
        fclose(dest_file);

        remove(opened);
    }
    else if (strcmp(space[1], "-n") == 0)
    {
        source_file = fopen(space[2], "r");
        if (source_file == NULL)
        {
            fprintf(stderr, "Cannot open source file %s\n", space[2]);
        }

        dest_file = fopen(space[3], "r");
        if (dest_file != NULL)
        {
            // Destination file already exists
            fclose(dest_file);
            printf("cp: overwrite '%s'?", space[3]);
            char response[10];
            fgets(response, sizeof(response), stdin);
            if (response[0] != 'y' && response[0] != 'Y')
            {
                printf("cp: not overwritten\n");
                fclose(source_file);
                // exit(EXIT_SUCCESS);
            }
        }

        dest_file = fopen(space[3], "w");
        if (dest_file == NULL)
        {
            fprintf(stderr, "Cannot open destination file %s\n", space[3]);
            fclose(source_file);
            // exit(EXIT_FAILURE);
        }

        // Copy the source file to the destination file if it does not exist already
        if (source_file != NULL && dest_file != NULL)
        {
            char buffer[BUFFER_SIZE];
            size_t bytes_read;
            while ((bytes_read = fread(buffer, 1, sizeof(buffer), source_file)) > 0)
            {
                fwrite(buffer, 1, bytes_read, dest_file);
            }
        }

        fclose(source_file);
        fclose(dest_file);
        // exit(EXIT_SUCCESS);
        remove(opened);
    }
    else if (strcmp(space[1], "-v") == 0)
    {
        strcpy(opened, space[2]);
        source_file = fopen(opened, "r");
        if (source_file == NULL)
        {
            fprintf(stderr, "Cannot open source file %s\n", opened);
        }
        dest_file = fopen(closed, "w");
        if (dest_file == NULL)
        {
            fprintf(stderr, "Cannot open destination file %s\n", closed);
            fclose(source_file);
        }
        if (source_file != NULL && dest_file != NULL)
        {
            char buffer[BUFFER_SIZE];
            size_t bytes_read;
            while ((bytes_read = fread(buffer, 1, sizeof(buffer), source_file)) > 0)
            {
                fwrite(buffer, 1, bytes_read, dest_file);
            }
        }

        fclose(source_file);
        close(dest_file);

        printf("%s -> %s: OK\n", space[2], space[3]);
        remove(opened);
    }
    else if (strcmp(space[1], "-f") == 0)
    {
        strcpy(opened, space[2]);
        source_file = fopen(opened, "r");
        if (source_file == NULL)
        {
            fprintf(stderr, "Cannot open source file %s\n", opened);
        }
        strcpy(closed, space[3]);
        dest_file = fopen(closed, "w");
        if (dest_file == NULL)
        {
            fprintf(stderr, "Cannot open destination file %s\n", closed);
            fclose(source_file);
        }

        if (source_file != NULL && dest_file != NULL)
        {
            char buffer[BUFFER_SIZE];
            size_t bytes_read;
            while ((bytes_read = fread(buffer, 1, sizeof(buffer), source_file)) > 0)
            {
                fwrite(buffer, 1, bytes_read, dest_file);
            }
        }

        fclose(source_file);
        fclose(dest_file);

        remove(opened);
    }
    else
    {
        strcpy(opened, space[1]);
        source_file = fopen(opened, "r");
        if (source_file == NULL)
        {
            printf("Error opening source file. %s\n ", opened);
        }
        strcpy(closed, space[2]);
        dest_file = fopen(closed, "w");
        if (dest_file == NULL)
        {
            printf("Error opening destination file.\n");
        }

        while ((c = fgetc(source_file)) != EOF)
        {
            fputc(c, dest_file);
        }

        printf("File copied successfully.\n");

        fclose(source_file);
        fclose(dest_file);

        remove(opened);
    }
}
