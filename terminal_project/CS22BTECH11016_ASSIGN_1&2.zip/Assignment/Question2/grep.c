#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <readline/readline.h>
#include <readline/history.h>

#define MAX_LINE_LENGTH 256

int grep(char *command_line)
{
    char *space[1000];
    int i = 0;

    // fgets(command_line, sizeof(command_line), stdin);
    char *token = strtok(command_line, " ");

    while (token != NULL)
    {
        space[i] = token;
        i++;
        token = strtok(NULL, " ");
    }
    if (strcmp(space[1], "-H") == 0)
    {
        {
            char *search_term = space[2];
            char *filename = space[3];

            FILE *file = fopen(filename, "r");
            if (file == NULL)
            {
                fprintf(stderr, "Error opening file %s\n", filename);
                return 1;
            }

            char line[MAX_LINE_LENGTH];
            while (fgets(line, MAX_LINE_LENGTH, file))
            {
                if (strstr(line, search_term))
                {
                    printf("%s:%s", filename, line);
                }
            }

            fclose(file);
        }
    }
    else if (strcmp(space[1], "-n") == 0)
    {
        char *search_term = space[2];
        char *filename = space[3];

        FILE *file = fopen(filename, "r");
        if (file == NULL)
        {
            fprintf(stderr, "Error opening file %s\n", filename);
            return 1;
        }

        char line[MAX_LINE_LENGTH];
        int line_number = 0;
        while (fgets(line, MAX_LINE_LENGTH, file))
        {
            line_number++;
            if (strstr(line, search_term))
            {
                printf("%d:%s", line_number, line);
            }
        }

        fclose(file);
    }
    else if (strcmp(space[1], "-c") == 0)
    {
        char *search_term = space[2];
        char *filename = space[3];

        FILE *file = fopen(filename, "r");
        if (file == NULL)
        {
            fprintf(stderr, "Error opening file %s\n", filename);
            return 1;
        }

        char line[MAX_LINE_LENGTH];
        int count = 0;
        while (fgets(line, MAX_LINE_LENGTH, file))
        {
            if (strstr(line, search_term))
            {
                count++;
            }
        }

        printf("%d\n", count);

        fclose(file);
    }
    else if (strcmp(space[1], "-v") == 0)
    {
        char *search_term = space[2];
        char *filename = space[3];

        FILE *file = fopen(filename, "r");
        if (file == NULL)
        {
            fprintf(stderr, "Error opening file %s\n", filename);
            return 1;
        }

        char line[MAX_LINE_LENGTH];
        while (fgets(line, MAX_LINE_LENGTH, file))
        {
            if (!strstr(line, search_term))
            {
                printf("%s", line);
            }
        }

        fclose(file);
    }

    else
    {
        char *search_term = space[1];
        char *filename = space[2];

        FILE *file = fopen(filename, "r");
        if (file == NULL)
        {
            fprintf(stderr, "Error opening file %s\n", filename);
            return 1;
        }

        char line[MAX_LINE_LENGTH];
        while (fgets(line, MAX_LINE_LENGTH, file))
        {
            if (strstr(line, search_term))
            {
                printf("%s", line);
            }
        }

        fclose(file);
    }
}