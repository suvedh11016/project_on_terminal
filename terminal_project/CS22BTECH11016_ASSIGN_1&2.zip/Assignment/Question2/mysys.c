#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <readline/readline.h>
#include <readline/history.h>
#define ANSI_COLOR_RED "\x1b[31m"
#define ANSI_COLOR_GREEN "\x1b[32m"
#define ANSI_COLOR_YELLOW "\x1b[33m"
#define ANSI_COLOR_BLUE "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN "\x1b[36m"
#define ANSI_COLOR_RESET "\x1b[0m"
char *command_line;
void ls_l();
void ls_r();
void ls_a();
void ls_U();
void ls_s();
void ls();
void cp(char *);
void mv(char *);
int grep(char *);
void main()
{
	char prompt[2000];
	// char *space[1000];
	char array[1000];
	gethostname(array, 1000);
	char *suv = getlogin();
	char edh[1000];
	getcwd(edh, 1000);
	char at[50] = {'@'};
	char sim[50] = {'~'};
	char dol[50] = {'$'};
	char semi[50] = {':'};
	char gap[50] = {' '};
	/*printf("\033[0;32m");
	  printf("%s@%s",array,suv);
	  printf("\033[0m");
	  printf(":");
	  printf("\033[0;34m");
	  printf("~%s",edh);
	  printf("\033[0m");
	char *done[1000];
	// printf("\033[0;32m");
	strcat(suv, at);
	strcat(suv, array);
		printf("\033[0;32m");
			scanf("%s",char *suv);
			printf("\033[0m");
	// scanf(ANSI_COLOR_GREEN "%s",suv);
	strcat(suv, semi);
	strcat(suv, sim);
		printf("\033[0;34m");
			scanf("%s",suv);
			printf("\033[0m");
	// scanf(ANSI_COLOR_BLUE "%s",edh);
	strcat(suv, edh);
	// printf("\033[0m");
	// printf("\033[0;34m");
	strcat(suv, sim);
	// printf("\033[0m");
	strcat(suv, dol);
	strcat(suv, gap);*/
	sprintf(prompt, ANSI_COLOR_GREEN "%s" ANSI_COLOR_GREEN "@%s" ":" ANSI_COLOR_BLUE "~%s" ANSI_COLOR_RESET "~$ ", suv,array,edh);
	printf("welcome to my terminal\n");
	while (1)
	{
		// char *token = strtok(command_line, " ");
		// int i=0;
		/*while (token != NULL)
		{
			space[i] = token;
			i++;
			token = strtok(NULL, " ");
		}*/
		printf("\033[0;32m");
		// printf("%s@%s",array,suv);
		// command_line = readline(done);
		printf("\033[0m");
		// printf(":");
		printf("\033[0;34m");
		// printf("~%s",edh);
		// command_line = readline(edh);
		printf("\033[0m");
		// printf("$");
		command_line = readline(prompt);
		/*char *token = strtok(command_line, " ");
		while (token != NULL)
		{
			space[i] = token;
			i++;
			token = strtok(NULL, " ");
		}*/
		if (strlen(command_line) > 0)
		{
			add_history(command_line);
		}
		if (!strcmp(command_line, "help"))
		{
			system("bash -c help");
		}
		else if (!strcmp(command_line, "date"))
		{
			system("date");
		}
		else if (!strcmp(command_line, "exit"))
		{
			printf("exited from terminal\n");
			break;
		}
		else if (!strcmp(command_line, "clear"))
		{
			system("clear");
		}
		if (strstr(command_line, "ls") != NULL)
		{
			if (strstr(command_line, "-l") != NULL)
			{
				ls_l();
			}
			else if (strstr(command_line, "-r") != NULL)
			{
				ls_r();
			}
			else if (strstr(command_line, "-U") != NULL)
			{
				ls_U();
			}
			else if (strstr(command_line, "-a") != NULL)
			{
				ls_a();
			}
			else if (strstr(command_line, "-s") != NULL)
			{
				ls_s();
			}
			else
			{
				ls();
			}
		}
		else if (strstr(command_line, "cp") != NULL)
		{
			cp(command_line);
		}
		else if (strstr(command_line, "grep") != NULL)
		{
			grep(command_line);
		}
		else if (strstr(command_line, "mv") != NULL)
		{
			mv(command_line);
		}
	}
}
